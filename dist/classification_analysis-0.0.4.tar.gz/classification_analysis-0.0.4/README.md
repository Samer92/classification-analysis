

# classification-analysis

The main target of this module is to:
1. Provides a dashboard to monitor your model during the training process.
2. Helps track the metric that you choose to find the best model for your problem.

In order to install, open the command prompt and type:
```
pip install classification_analysis
```

Refer to the following [notebook](https://github.com/Samer92/classification-analysis/tree/master/example) to see some code examples